class CartUI {
    constructor() {
        this.cartContainer = document.getElementById('cartItemsContainer');
        this.cartTotal = document.getElementById('cartTotal');
        this.checkoutBtn = document.getElementById('checkoutBtn');
        this.emptyCartMessage = document.getElementById('emptyCartMessage');
        this.toastContainer = document.getElementById('toastContainer');

        this.items = [];
        this.initEventListeners();
    }

    initEventListeners() {
        this.checkoutBtn.addEventListener('click', this.processCheckout.bind(this));
    }

    addItem(item) {
        if (this.items.some(i => i.id === item.id)) {
            this.showToast('Item already in cart', 'warning');
            return false;
        }

        this.items.push(item);
        this.renderCart();
        this.showToast(`${item.name} added to cart`, 'success');
        return true;
    }

    removeItem(index) {
        this.items.splice(index, 1);
        this.renderCart();
        this.showToast('Item removed', 'info');
    }

    renderCart() {
        this.cartContainer.innerHTML = '';

        if (this.items.length === 0) {
            this.emptyCartMessage.style.display = 'block';
            this.checkoutBtn.disabled = true;
            this.cartTotal.textContent = '$0.00';
            return;
        }

        this.emptyCartMessage.style.display = 'none';
        this.checkoutBtn.disabled = false;

        this.items.forEach((item, index) => {
            const cartItemElement = document.createElement('div');
            cartItemElement.className = 'cart-item d-flex align-items-center';
            cartItemElement.innerHTML = `
                <div class="flex-shrink-0 me-3">
                    <img src="${item.image}" alt="${item.name}" class="img-fluid">
                </div>
                <div class="flex-grow-1">
                    <h6 class="mb-1">${item.name}</h6>
                    <p class="text-muted mb-1">${item.category || 'Pet'}</p>
                    <p class="fw-bold text-primary mb-0">$${item.price}</p>
                </div>
                <div>
                    <button class="btn btn-sm btn-danger remove-item" data-index="${index}">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            `;

            const removeButton = cartItemElement.querySelector('.remove-item');
            removeButton.addEventListener('click', () => this.removeItem(index));

            this.cartContainer.appendChild(cartItemElement);
        });

        this.updateTotal();
    }

    updateTotal() {
        const total = this.items.reduce((sum, item) => sum + item.price, 0);
        this.cartTotal.textContent = `$${total.toFixed(2)}`;
    }

    processCheckout() {
        if (this.items.length === 0) {
            this.showToast('Your cart is empty', 'warning');
            return;
        }

        const total = this.items.reduce((sum, item) => sum + item.price, 0);
        const confirmed = confirm(`Checkout ${this.items.length} items for $${total.toFixed(2)}?`);

        if (confirmed) {
            this.completeCheckout();
        }
    }

    completeCheckout() {
        // Simulated checkout process
        this.showToast('Checkout successful!', 'success');
        this.items = [];
        this.renderCart();
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-bg-${type} border-0`;
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;

        this.toastContainer.appendChild(toast);
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.cartUI = new CartUI();
});