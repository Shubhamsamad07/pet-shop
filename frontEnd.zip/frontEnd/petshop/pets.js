class PetGallery {
    constructor() {
        this.pets = [
            { id: 1, name: 'Fluffy', category: 'cat', breed: 'Persian', age: 2, price: 500, image: 'https://placekitten.com/400/300' },
            { id: 2, name: 'Buddy', category: 'dog', breed: 'Golden Retriever', age: 3, price: 800, image: 'https://placedog.net/400/300' },
            { id: 3, name: 'Polly', category: 'bird', breed: 'Parrot', age: 1, price: 250, image: 'https://via.placeholder.com/400x300' },
            { id: 4, name: 'Whiskers', category: 'cat', breed: 'Siamese', age: 4, price: 450, image: 'https://placekitten.com/400/301' },
            { id: 5, name: 'Rex', category: 'dog', breed: 'German Shepherd', age: 5, price: 600, image: 'https://placedog.net/400/301' }
        ];
        this.cart = [];
        this.initEventListeners();
        this.renderPets();
    }

    initEventListeners() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                // Remove active class from all buttons
                filterButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.renderPets(btn.dataset.category);
            });
        });
    }

    renderPets(category = 'all') {
        const gallery = document.getElementById('petGallery');
        gallery.innerHTML = '';

        const filteredPets = category === 'all' 
            ? this.pets 
            : this.pets.filter(pet => pet.category === category);

        filteredPets.forEach(pet => {
            const petCard = this.createPetCard(pet);
            gallery.appendChild(petCard);
        });
    }

    createPetCard(pet) {
        const col = document.createElement('div');
        col.className = 'pet-card card position-relative';
        col.innerHTML = `
            <img src="${pet.image}" class="card-img-top" alt="${pet.name}">
            <div class="price-tag">$${pet.price}</div>
            <div class="card-body">
                <h5 class="card-title">${pet.name}</h5>
                <p class="card-text">
                    Breed: ${pet.breed}<br>
                    Age: ${pet.age} years
                </p>
                <button class="btn btn-success add-to-cart" data-id="${pet.id}">
                    <i class="bi bi-cart-plus"></i> Add to Cart
                </button>
            </div>
        `;

        const addToCartBtn = col.querySelector('.add-to-cart');
        addToCartBtn.addEventListener('click', () => this.addToCart(pet));

        return col;
    }

    addToCart(pet) {
        // Use the new cart module to handle adding to cart
        const addedToCart = window.petPurchaseCart.addToCart(pet);
        
        if (addedToCart) {
            // Optional: Show a success toast or notification
            this.showAddToCartNotification(pet);
        }
    }
    
    showAddToCartNotification(pet) {
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-bg-success border-0 position-fixed top-0 end-0 m-3';
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${pet.name} added to cart!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        document.body.appendChild(toast);
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.petGallery = new PetGallery();
});