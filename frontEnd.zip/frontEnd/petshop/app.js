class PetShopApp {
    constructor() {
        this.isLoggedIn = false;
        this.cart = [];
        this.initEventListeners();
    }

    initEventListeners() {
        const loginBtn = document.getElementById('loginBtn');
        const loginForm = document.getElementById('loginForm');
        
        if (loginBtn) loginBtn.addEventListener('click', this.showLoginModal.bind(this));
        if (loginForm) loginForm.addEventListener('submit', this.handleLogin.bind(this));
    }

    showLoginModal() {
        const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
        loginModal.show();
    }

    handleLogin(event) {
        event.preventDefault();
        const email = event.target.querySelector('input[type="email"]').value;
        const password = event.target.querySelector('input[type="password"]').value;
        
        // Simulated login (replace with actual authentication)
        if (email && password) {
            this.isLoggedIn = true;
            this.updateLoginStatus();
            this.closeLoginModal();
            this.showWelcomeToast(email);
        }
    }

    updateLoginStatus() {
        const loginBtn = document.getElementById('loginBtn');
        if (loginBtn) {
            loginBtn.textContent = this.isLoggedIn ? 'Logout' : 'Login';
        }
    }

    closeLoginModal() {
        const loginModal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
        loginModal.hide();
    }

    showWelcomeToast(email) {
        const toastContainer = document.createElement('div');
        toastContainer.innerHTML = `
            <div class="toast-container position-fixed bottom-0 end-0 p-3">
                <div class="toast show" role="alert">
                    <div class="toast-header">
                        <strong class="me-auto">Welcome!</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
                    </div>
                    <div class="toast-body">
                        Welcome back, ${email}!
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(toastContainer);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.petShopApp = new PetShopApp();
});