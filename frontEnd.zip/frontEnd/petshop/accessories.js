class AccessoriesModule {
    constructor() {
        this.accessories = [
            {
                id: 1,
                name: 'Luxury Dog Bed',
                category: 'dog',
                price: 79.99,
                image: 'https://via.placeholder.com/300x250?text=Dog+Bed',
                description: 'Comfortable orthopedic bed for dogs of all sizes.',
                features: [
                    'Memory foam padding',
                    'Washable cover',
                    'Non-slip bottom'
                ]
            },
            {
                id: 2,
                name: 'Interactive Cat Toy',
                category: 'cat',
                price: 34.99,
                image: 'https://via.placeholder.com/300x250?text=Cat+Toy',
                description: 'Laser and motion-activated play toy for cats.',
                features: [
                    'Automatic laser movement',
                    'Battery-powered',
                    'Multiple play modes'
                ]
            },
            {
                id: 3,
                name: 'Bird Cage Perch Set',
                category: 'bird',
                price: 49.99,
                image: 'https://via.placeholder.com/300x250?text=Bird+Perch',
                description: 'Comfortable perch set for bird cages.',
                features: [
                    'Multiple sizes',
                    'Wooden construction',
                    'Easy installation'
                ]
            }
        ];

        this.initEventListeners();
        this.renderAccessories();
    }

    initEventListeners() {
        const categoryFilters = document.querySelectorAll('.category-filter');
        categoryFilters.forEach(filter => {
            filter.addEventListener('click', () => {
                // Remove active class from all filters
                categoryFilters.forEach(f => f.classList.remove('active'));
                filter.classList.add('active');
                
                this.renderAccessories(filter.dataset.category);
            });
        });
    }

    renderAccessories(category = 'all') {
        const grid = document.getElementById('accessoriesGrid');
        grid.innerHTML = '';

        const filteredAccessories = category === 'all' 
            ? this.accessories 
            : this.accessories.filter(acc => acc.category === category);

        filteredAccessories.forEach(accessory => {
            const card = this.createAccessoryCard(accessory);
            grid.appendChild(card);
        });
    }

    createAccessoryCard(accessory) {
        const card = document.createElement('div');
        card.className = 'card accessory-card';
        card.innerHTML = `
            <img src="${accessory.image}" class="card-img-top" alt="${accessory.name}">
            <div class="card-body">
                <h5 class="card-title">${accessory.name}</h5>
                <p class="card-text text-muted">${accessory.category.toUpperCase()} ACCESSORY</p>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="h5 mb-0 text-primary">$${accessory.price}</span>
                    <div>
                        <button class="btn btn-sm btn-outline-primary quick-view" data-id="${accessory.id}">
                            Quick View
                        </button>
                        <button class="btn btn-sm btn-success add-to-cart" data-id="${accessory.id}">
                            <i class="bi bi-cart-plus"></i> Add
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Quick View Event
        const quickViewBtn = card.querySelector('.quick-view');
        quickViewBtn.addEventListener('click', () => this.showQuickView(accessory));

        // Add to Cart Event
        const addToCartBtn = card.querySelector('.add-to-cart');
        addToCartBtn.addEventListener('click', () => this.addToCart(accessory));

        return card;
    }

    showQuickView(accessory) {
        const quickViewContent = document.getElementById('quickViewContent');
        quickViewContent.innerHTML = `
            <div class="modal-header">
                <h5 class="modal-title">${accessory.name}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <img src="${accessory.image}" class="img-fluid" alt="${accessory.name}">
                    </div>
                    <div class="col-md-6">
                        <h4>Description</h4>
                        <p>${accessory.description}</p>
                        <h5>Features</h5>
                        <ul class="list-unstyled">
                            ${accessory.features.map(feature => `<li><i class="bi bi-check-circle text-success me-2"></i>${feature}</li>`).join('')}
                        </ul>
                        <div class="h3 text-primary mt-3">$${accessory.price}</div>
                        <button class="btn btn-success add-to-cart mt-3" data-id="${accessory.id}">
                            <i class="bi bi-cart-plus"></i> Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        `;

        const modal = new bootstrap.Modal(document.getElementById('accessoryQuickView'));
        modal.show();

        // Re-attach add to cart event in modal
        const addToCartBtn = quickViewContent.querySelector('.add-to-cart');
        addToCartBtn.addEventListener('click', () => this.addToCart(accessory));
    }

    addToCart(accessory) {
        // Connect to cart module
        if (window.cartUI) {
            window.cartUI.addItem(accessory);
        } else {
            alert('Cart module not loaded');
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.accessoriesModule = new AccessoriesModule();
});